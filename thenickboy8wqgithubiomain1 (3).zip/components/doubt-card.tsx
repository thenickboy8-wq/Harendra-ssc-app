import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MessageCircle, ThumbsUp } from "lucide-react"

interface DoubtCardProps {
  id: string
  title: string
  description: string
  askedBy: string
  replies: number
  likes: number
  status: "open" | "resolved"
  subject: string
}

export default function DoubtCard({
  id,
  title,
  description,
  askedBy,
  replies,
  likes,
  status,
  subject,
}: DoubtCardProps) {
  return (
    <Card className="hover:shadow-md transition-shadow cursor-pointer">
      <CardHeader>
        <div className="flex justify-between items-start gap-4">
          <div className="flex-1">
            <CardTitle className="text-lg">{title}</CardTitle>
            <CardDescription>{description}</CardDescription>
          </div>
          <Badge variant={status === "resolved" ? "outline" : "secondary"}>
            {status === "resolved" ? "Resolved" : "Open"}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap justify-between items-center text-sm text-muted-foreground gap-4">
          <div className="space-x-3 flex">
            <Badge variant="outline" className="text-xs">
              {subject}
            </Badge>
            <span>Asked by {askedBy}</span>
          </div>
          <div className="flex gap-4">
            <div className="flex items-center gap-1">
              <MessageCircle size={16} />
              <span>{replies}</span>
            </div>
            <div className="flex items-center gap-1">
              <ThumbsUp size={16} />
              <span>{likes}</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
