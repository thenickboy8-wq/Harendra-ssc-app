"use client"

import { Card, CardContent } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

interface QuestionOption {
  id: string
  text: string
}

interface MockTestQuestionProps {
  questionNumber: number
  totalQuestions: number
  question: string
  options: QuestionOption[]
  selectedAnswer?: string
  onAnswerSelect: (answerId: string) => void
}

export default function MockTestQuestion({
  questionNumber,
  totalQuestions,
  question,
  options,
  selectedAnswer,
  onAnswerSelect,
}: MockTestQuestionProps) {
  return (
    <Card className="border-l-4 border-l-primary">
      <CardContent className="pt-6">
        <div className="mb-6">
          <div className="flex justify-between items-center mb-3">
            <span className="text-sm font-semibold text-primary">
              Question {questionNumber} of {totalQuestions}
            </span>
            <div className="w-full mx-4 bg-gray-200 rounded-full h-2">
              <div
                className="bg-primary h-2 rounded-full transition-all"
                style={{ width: `${(questionNumber / totalQuestions) * 100}%` }}
              ></div>
            </div>
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-6">{question}</h3>
        </div>

        <RadioGroup value={selectedAnswer || ""} onValueChange={onAnswerSelect}>
          <div className="space-y-3">
            {options.map((option) => (
              <div
                key={option.id}
                className={`flex items-center space-x-3 p-4 rounded-lg border-2 cursor-pointer transition-colors ${
                  selectedAnswer === option.id ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
                }`}
              >
                <RadioGroupItem value={option.id} id={option.id} />
                <Label htmlFor={option.id} className="flex-1 cursor-pointer font-medium">
                  {option.text}
                </Label>
              </div>
            ))}
          </div>
        </RadioGroup>
      </CardContent>
    </Card>
  )
}
