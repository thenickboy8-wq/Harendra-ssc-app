import { Play, Users } from "lucide-react"

interface LiveClassCardProps {
  id: number
  subject: string
  instructor: string
  time: string
  date: string
  students: number
  status: "LIVE" | "UPCOMING"
}

export default function LiveClassCard({ subject, instructor, time, date, students, status }: LiveClassCardProps) {
  const isLive = status === "LIVE"

  return (
    <div
      className={`rounded-lg border-2 p-6 transition ${
        isLive ? "bg-gradient-to-br from-red-50 to-orange-50 border-red-300" : "bg-white border-border hover:shadow-lg"
      }`}
    >
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-bold text-foreground mb-1">{subject}</h3>
          <p className="text-sm text-muted-foreground">by {instructor}</p>
        </div>
        {isLive && (
          <div className="flex items-center gap-2 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold animate-pulse">
            <Play size={14} fill="white" />
            LIVE
          </div>
        )}
      </div>

      <div className="space-y-2 mb-4">
        <div className="text-sm text-muted-foreground">
          <span className="font-semibold text-foreground">{time}</span> • {date}
        </div>
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <Users size={16} />
          <span>{students} students joined</span>
        </div>
      </div>

      <button
        className={`w-full py-2 rounded-lg font-semibold transition ${
          isLive ? "bg-red-500 text-white hover:bg-red-600" : "bg-primary text-white hover:bg-primary-dark"
        }`}
      >
        {isLive ? "Join Now" : "Set Reminder"}
      </button>
    </div>
  )
}
