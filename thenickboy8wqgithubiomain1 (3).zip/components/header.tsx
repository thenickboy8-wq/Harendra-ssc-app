"use client"

import Link from "next/link"
import { Menu, X, Bell, User } from "lucide-react"
import { useState } from "react"

export default function Header() {
  const [isOpen, setIsOpen] = useState(false)

  const navLinks = [
    { label: "Home", href: "/" },
    { label: "Live Classes", href: "/live-classes" },
    { label: "Test Series", href: "/test-series" },
    { label: "Doubts", href: "/doubt-section" },
    { label: "Syllabus", href: "/syllabus" },
    { label: "About", href: "/about" },
    { label: "Contact", href: "/contact" },
  ]

  return (
    <header className="bg-white border-b border-border sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold text-primary">
          Selection Way
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex gap-8 items-center flex-1 justify-center">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-foreground hover:text-primary transition font-medium text-sm"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Desktop Right Icons */}
        <div className="hidden md:flex gap-4 items-center">
          <button className="p-2 hover:bg-muted rounded-lg transition">
            <Bell size={20} className="text-foreground" />
          </button>
          <Link href="/dashboard" className="p-2 hover:bg-muted rounded-lg transition">
            <User size={20} className="text-foreground" />
          </Link>
          <Link
            href="/login"
            className="bg-primary text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700 transition"
          >
            Login
          </Link>
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <nav className="md:hidden bg-muted border-t border-border p-4 animate-in">
          <div className="flex flex-col gap-4">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-foreground hover:text-primary transition font-medium"
              >
                {link.label}
              </Link>
            ))}
            <div className="pt-4 border-t border-border space-y-3">
              <Link
                href="/login"
                className="block w-full bg-primary text-white px-6 py-2 rounded-lg font-semibold text-center hover:bg-blue-700 transition"
              >
                Login
              </Link>
              <Link
                href="/signup"
                className="block w-full border-2 border-primary text-primary px-6 py-2 rounded-lg font-semibold text-center hover:bg-blue-50 transition"
              >
                Sign Up
              </Link>
            </div>
          </div>
        </nav>
      )}
    </header>
  )
}
