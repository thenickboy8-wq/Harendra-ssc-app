import Link from "next/link"
import { Mail, Phone, MapPin, Facebook, Twitter, Instagram } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-foreground text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Selection Way</h3>
            <p className="text-white/80">Prepare smart, qualify faster with live classes and expert guidance.</p>
          </div>
          <div>
            <h4 className="font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-white/80 hover:text-white transition">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/syllabus" className="text-white/80 hover:text-white transition">
                  Syllabus
                </Link>
              </li>
              <li>
                <Link href="/live-classes" className="text-white/80 hover:text-white transition">
                  Live Classes
                </Link>
              </li>
              <li>
                <Link href="/notifications" className="text-white/80 hover:text-white transition">
                  Notifications
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">Contact Info</h4>
            <ul className="space-y-3">
              <li className="flex gap-2 items-start text-white/80">
                <Mail size={18} className="mt-1 flex-shrink-0" />
                <span>harendra@selectionway.com</span>
              </li>
              <li className="flex gap-2 items-start text-white/80">
                <Phone size={18} className="mt-1 flex-shrink-0" />
                <span>+91-9876543210</span>
              </li>
              <li className="flex gap-2 items-start text-white/80">
                <MapPin size={18} className="mt-1 flex-shrink-0" />
                <span>Delhi, India</span>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">Follow Us</h4>
            <div className="flex gap-4">
              <a href="#" className="hover:text-primary transition">
                <Facebook size={20} />
              </a>
              <a href="#" className="hover:text-primary transition">
                <Twitter size={20} />
              </a>
              <a href="#" className="hover:text-primary transition">
                <Instagram size={20} />
              </a>
            </div>
          </div>
        </div>
        <div className="border-t border-white/20 pt-8 text-center text-white/80">
          <p>&copy; 2025 Selection Way Harendra SSC. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
