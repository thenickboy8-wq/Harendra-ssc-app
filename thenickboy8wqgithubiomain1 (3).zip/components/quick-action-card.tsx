import Link from "next/link"
import type { LucideIcon } from "lucide-react"

interface QuickActionCardProps {
  icon: LucideIcon
  title: string
  description: string
  href: string
  color: string
}

export default function QuickActionCard({ icon: Icon, title, description, href, color }: QuickActionCardProps) {
  return (
    <Link href={href}>
      <div className="bg-white rounded-lg p-6 shadow-sm border border-border hover:shadow-lg transition cursor-pointer">
        <div className={`${color} w-12 h-12 rounded-lg flex items-center justify-center mb-4`}>
          <Icon className="text-foreground" size={24} />
        </div>
        <h3 className="font-bold text-lg text-foreground mb-2">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </Link>
  )
}
