import type React from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { FileText, Clock } from "lucide-react"

interface TestSeriesCardProps {
  id: string
  title: string
  description: string
  totalTests: number
  difficulty: string
  duration: string
  icon?: React.ReactNode
  href: string
}

export default function TestSeriesCard({
  id,
  title,
  description,
  totalTests,
  difficulty,
  duration,
  href,
}: TestSeriesCardProps) {
  const difficultyColor = {
    Easy: "bg-green-100 text-green-800",
    Medium: "bg-yellow-100 text-yellow-800",
    Hard: "bg-red-100 text-red-800",
  }

  return (
    <Card className="hover:shadow-lg transition-shadow h-full flex flex-col">
      <CardHeader>
        <div className="flex justify-between items-start gap-4">
          <div className="flex-1">
            <CardTitle className="text-xl">{title}</CardTitle>
            <CardDescription>{description}</CardDescription>
          </div>
          <Badge className={difficultyColor[difficulty as keyof typeof difficultyColor]}>{difficulty}</Badge>
        </div>
      </CardHeader>
      <CardContent className="flex-1">
        <div className="space-y-3 mb-6">
          <div className="flex items-center gap-2 text-sm">
            <FileText size={16} className="text-primary" />
            <span>{totalTests} Tests</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Clock size={16} className="text-primary" />
            <span>{duration} per test</span>
          </div>
        </div>
      </CardContent>
      <div className="px-6 pb-6">
        <Link href={href} className="w-full">
          <Button className="w-full">Start Test Series</Button>
        </Link>
      </div>
    </Card>
  )
}
