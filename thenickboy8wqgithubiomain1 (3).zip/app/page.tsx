"use client"

import Link from "next/link"
import { Calendar, Users, ArrowRight, Users2 } from "lucide-react"
import Header from "@/components/header"
import Footer from "@/components/footer"

export default function Home() {
  const liveClasses = [
    {
      id: 1,
      subject: "General Awareness",
      instructor: "Harendra Sir",
      time: "10:00 AM",
      date: "Today",
      students: 245,
      status: "LIVE",
    },
    {
      id: 2,
      subject: "Quantitative Aptitude",
      instructor: "Priya Ma'am",
      time: "2:00 PM",
      date: "Today",
      students: 189,
      status: "UPCOMING",
    },
    {
      id: 3,
      subject: "English Language",
      instructor: "Sharma Sir",
      time: "4:30 PM",
      date: "Tomorrow",
      students: 167,
      status: "UPCOMING",
    },
  ]

  return (
    <main className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary via-blue-500 to-blue-600 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-balance">Selection Way Harendra SSC</h1>
          <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-3xl mx-auto">
            Prepare Smart, Qualify Faster — Live Classes, Mock Tests & Expert Guidance
          </p>
          <div className="flex justify-center gap-4 flex-wrap">
            <Link
              href="/dashboard"
              className="bg-white text-primary px-8 py-4 rounded-lg font-bold hover:bg-gray-100 transition text-lg"
            >
              Join Now
            </Link>
            <Link
              href="/test-series"
              className="border-2 border-white text-white px-8 py-4 rounded-lg font-bold hover:bg-white/10 transition text-lg"
            >
              Start Mock Test
            </Link>
          </div>
        </div>
      </section>

      {/* Quick Stats */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-xl p-8 shadow-lg border-l-4 border-primary text-center">
            <div className="text-4xl font-bold text-primary mb-2">1000+</div>
            <p className="text-muted-foreground font-semibold">Active Students</p>
          </div>
          <div className="bg-white rounded-xl p-8 shadow-lg border-l-4 border-blue-500 text-center">
            <div className="text-4xl font-bold text-blue-500 mb-2">50+</div>
            <p className="text-muted-foreground font-semibold">Live Classes Monthly</p>
          </div>
          <div className="bg-white rounded-xl p-8 shadow-lg border-l-4 border-green-500 text-center">
            <div className="text-4xl font-bold text-green-500 mb-2">95%</div>
            <p className="text-muted-foreground font-semibold">Selection Rate</p>
          </div>
          <div className="bg-white rounded-xl p-8 shadow-lg border-l-4 border-orange-500 text-center">
            <div className="text-4xl font-bold text-orange-500 mb-2">24/7</div>
            <p className="text-muted-foreground font-semibold">Study Support</p>
          </div>
        </div>
      </section>

      {/* Live Classes */}
      <section className="bg-muted py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-foreground">Today's Live Classes</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {liveClasses.map((liveClass) => (
              <div
                key={liveClass.id}
                className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition border border-border"
              >
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-xl font-bold text-foreground">{liveClass.subject}</h3>
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-semibold ${
                        liveClass.status === "LIVE" ? "bg-red-100 text-red-700" : "bg-blue-100 text-blue-700"
                      }`}
                    >
                      {liveClass.status}
                    </span>
                  </div>
                  <p className="text-gray-600 mb-3 flex items-center gap-2">
                    <Users2 size={18} />
                    {liveClass.instructor}
                  </p>
                  <p className="text-gray-600 mb-3 flex items-center gap-2">
                    <Calendar size={18} />
                    {liveClass.date} at {liveClass.time}
                  </p>
                  <p className="text-gray-600 mb-4 flex items-center gap-2">
                    <Users size={18} />
                    {liveClass.students} students
                  </p>
                  <button className="w-full bg-primary text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition">
                    Join Class
                  </button>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center">
            <Link
              href="/live-classes"
              className="inline-flex items-center gap-2 text-primary font-bold text-lg hover:gap-3 transition"
            >
              View All Classes <ArrowRight size={20} />
            </Link>
          </div>
        </div>
      </section>

      {/* Test Series */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-4xl font-bold mb-12 text-foreground">Test Series & Mock Tests</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {[
            { name: "SSC JE", exams: "100+ Tests", color: "from-blue-500 to-blue-600" },
            { name: "SSC CGL", exams: "80+ Tests", color: "from-purple-500 to-purple-600" },
            { name: "RSMASB JE", exams: "60+ Tests", color: "from-green-500 to-green-600" },
          ].map((series, i) => (
            <Link key={i} href="/test-series" className="group">
              <div
                className={`bg-gradient-to-r ${series.color} text-white rounded-xl p-8 shadow-lg hover:shadow-xl transition transform hover:scale-105`}
              >
                <h3 className="text-2xl font-bold mb-2">{series.name}</h3>
                <p className="text-white/90 mb-6">{series.exams}</p>
                <button className="bg-white text-gray-900 px-6 py-2 rounded-lg font-semibold hover:bg-gray-100 transition">
                  Start Practice
                </button>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="bg-muted py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-foreground text-center">Why Choose Us?</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: "📚", title: "Complete Study Material", desc: "All topics covered with detailed notes" },
              { icon: "🎥", title: "Live Classes", desc: "Real-time interaction with expert instructors" },
              { icon: "✅", title: "Mock Tests", desc: "Realistic exam simulations & analysis" },
              { icon: "💬", title: "Doubt Support", desc: "24/7 Q&A section & expert guidance" },
            ].map((feature, i) => (
              <div key={i} className="bg-white rounded-xl p-8 shadow-lg text-center hover:shadow-xl transition">
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-bold mb-3 text-foreground">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto px-4 py-16">
        <div className="bg-gradient-to-r from-primary to-blue-600 text-white rounded-2xl p-12 text-center">
          <h2 className="text-4xl font-bold mb-4">Start Your SSC Preparation Today</h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Join thousands of successful students who cracked SSC exams with Selection Way Harendra.
          </p>
          <div className="flex justify-center gap-4">
            <Link
              href="/dashboard"
              className="bg-white text-primary px-8 py-4 rounded-lg font-bold hover:bg-gray-100 transition"
            >
              Enroll Now
            </Link>
            <Link
              href="/contact"
              className="border-2 border-white text-white px-8 py-4 rounded-lg font-bold hover:bg-white/10 transition"
            >
              Get in Touch
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
