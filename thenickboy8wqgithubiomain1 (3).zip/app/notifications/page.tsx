import Header from "@/components/header"
import Footer from "@/components/footer"
import { Bell } from "lucide-react"

export const metadata = {
  title: "Notifications - Selection Way Harendra",
  description: "Latest updates and announcements",
}

export default function NotificationsPage() {
  const notifications = [
    {
      id: 1,
      title: "New Batch Starts Tomorrow",
      description: "Join our advanced batch for SSC preparation. Limited seats available!",
      date: "Today",
      type: "announcement",
    },
    {
      id: 2,
      title: "Free Mock Test Available",
      description: "Take our latest mock test and check your preparation level.",
      date: "Yesterday",
      type: "update",
    },
    {
      id: 3,
      title: "SSC Exam Date Announced",
      description: "SSC has announced the exam dates for 2025. Check official website for details.",
      date: "2 days ago",
      type: "important",
    },
    {
      id: 4,
      title: "Doubt Clearing Session",
      description: "Live doubt clearing session on Reasoning scheduled for today at 7 PM.",
      date: "3 days ago",
      type: "update",
    },
  ]

  return (
    <>
      <Header />
      <main className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-4xl font-bold mb-3 text-foreground">Notifications & Updates</h1>
          <p className="text-lg text-muted-foreground mb-12">
            Stay updated with latest announcements and important information
          </p>

          <div className="space-y-4 max-w-2xl">
            {notifications.map((notif) => (
              <div
                key={notif.id}
                className={`p-6 rounded-lg border-l-4 ${
                  notif.type === "important"
                    ? "bg-red-50 border-l-red-500"
                    : notif.type === "announcement"
                      ? "bg-blue-50 border-l-blue-500"
                      : "bg-green-50 border-l-green-500"
                } border border-border`}
              >
                <div className="flex gap-4">
                  <Bell
                    className={`flex-shrink-0 mt-1 ${
                      notif.type === "important"
                        ? "text-red-500"
                        : notif.type === "announcement"
                          ? "text-blue-500"
                          : "text-green-500"
                    }`}
                  />
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-foreground mb-2">{notif.title}</h3>
                    <p className="text-muted-foreground mb-3">{notif.description}</p>
                    <span className="text-sm text-muted-foreground">{notif.date}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
