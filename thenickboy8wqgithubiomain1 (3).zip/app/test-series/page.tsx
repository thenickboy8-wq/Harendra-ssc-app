"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import TestSeriesCard from "@/components/test-series-card"
import Header from "@/components/header"
import Footer from "@/components/footer"

export default function TestSeriesPage() {
  const sscJETests = [
    {
      id: "ssc-je-1",
      title: "SSC JE Preliminary - General Awareness",
      description: "Test your knowledge on General Awareness topics",
      totalTests: 15,
      difficulty: "Medium",
      duration: "120 min",
      href: "/test-series/ssc-je",
    },
    {
      id: "ssc-je-2",
      title: "SSC JE Preliminary - Engineering",
      description: "Civil, Mechanical, and Electrical Engineering",
      totalTests: 20,
      difficulty: "Hard",
      duration: "150 min",
      href: "/test-series/ssc-je",
    },
    {
      id: "ssc-je-3",
      title: "SSC JE Mains - Full Length Test",
      description: "Complete mock test simulating actual exam",
      totalTests: 10,
      difficulty: "Hard",
      duration: "180 min",
      href: "/test-series/ssc-je",
    },
  ]

  const sscCGLTests = [
    {
      id: "ssc-cgl-1",
      title: "SSC CGL Tier 1 - General Awareness",
      description: "Current affairs, history, geography, and science",
      totalTests: 25,
      difficulty: "Easy",
      duration: "60 min",
      href: "/test-series/ssc-cgl",
    },
    {
      id: "ssc-cgl-2",
      title: "SSC CGL Tier 1 - Quantitative Aptitude",
      description: "Mathematics, arithmetic, and data interpretation",
      totalTests: 20,
      difficulty: "Medium",
      duration: "60 min",
      href: "/test-series/ssc-cgl",
    },
    {
      id: "ssc-cgl-3",
      title: "SSC CGL Tier 1 - English Language",
      description: "Grammar, vocabulary, comprehension, and more",
      totalTests: 18,
      difficulty: "Easy",
      duration: "60 min",
      href: "/test-series/ssc-cgl",
    },
    {
      id: "ssc-cgl-4",
      title: "SSC CGL Tier 2 - Full Length Test",
      description: "Complete Tier 2 exam simulation",
      totalTests: 8,
      difficulty: "Hard",
      duration: "120 min",
      href: "/test-series/ssc-cgl",
    },
  ]

  const rsmasbJETests = [
    {
      id: "rsmash-je-1",
      title: "RSMASB JE - Civil Engineering",
      description: "Comprehensive civil engineering test series",
      totalTests: 12,
      difficulty: "Hard",
      duration: "150 min",
      href: "/test-series/rsmasb-je",
    },
    {
      id: "rsmash-je-2",
      title: "RSMASB JE - Mechanical Engineering",
      description: "Mechanical engineering focused tests",
      totalTests: 10,
      difficulty: "Hard",
      duration: "150 min",
      href: "/test-series/rsmasb-je",
    },
    {
      id: "rsmash-je-3",
      title: "RSMASB JE - Full Length Mock Test",
      description: "Complete examination simulation",
      totalTests: 6,
      difficulty: "Hard",
      duration: "180 min",
      href: "/test-series/rsmasb-je",
    },
  ]

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-12">
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4">Test Series</h1>
          <p className="text-lg text-muted-foreground">
            Comprehensive mock tests to prepare for SSC exams. Choose your exam and start practicing.
          </p>
        </div>

        <Tabs defaultValue="ssc-je" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="ssc-je">SSC JE</TabsTrigger>
            <TabsTrigger value="ssc-cgl">SSC CGL</TabsTrigger>
            <TabsTrigger value="rsmasb-je">RSMASB JE</TabsTrigger>
          </TabsList>

          <TabsContent value="ssc-je" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sscJETests.map((test) => (
                <TestSeriesCard key={test.id} {...test} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="ssc-cgl" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sscCGLTests.map((test) => (
                <TestSeriesCard key={test.id} {...test} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="rsmasb-je" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {rsmasbJETests.map((test) => (
                <TestSeriesCard key={test.id} {...test} />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>

      <Footer />
    </div>
  )
}
