"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import MockTestQuestion from "@/components/mock-test-question"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { ArrowRight, ArrowLeft, CheckCircle } from "lucide-react"

export default function SSCJETestPage() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [isTestStarted, setIsTestStarted] = useState(false)

  const questions = [
    {
      id: 1,
      question: "What is the SI unit of force?",
      options: [
        { id: "a", text: "Kilogram (kg)" },
        { id: "b", text: "Newton (N)" },
        { id: "c", text: "Pascal (Pa)" },
        { id: "d", text: "Joule (J)" },
      ],
    },
    {
      id: 2,
      question: "Which of the following is a renewable source of energy?",
      options: [
        { id: "a", text: "Coal" },
        { id: "b", text: "Natural Gas" },
        { id: "c", text: "Solar Energy" },
        { id: "d", text: "Petroleum" },
      ],
    },
    {
      id: 3,
      question: "What is the main component of natural gas?",
      options: [
        { id: "a", text: "Ethane" },
        { id: "b", text: "Propane" },
        { id: "c", text: "Methane" },
        { id: "d", text: "Butane" },
      ],
    },
    {
      id: 4,
      question: "The Young's modulus of a material is related to its?",
      options: [
        { id: "a", text: "Elasticity" },
        { id: "b", text: "Plasticity" },
        { id: "c", text: "Brittleness" },
        { id: "d", text: "Ductility" },
      ],
    },
    {
      id: 5,
      question: "Which concrete mix is used for road construction?",
      options: [
        { id: "a", text: "1:1:2" },
        { id: "b", text: "1:2:4" },
        { id: "c", text: "1:3:6" },
        { id: "d", text: "1:4:8" },
      ],
    },
  ]

  const handleAnswerSelect = (answerId: string) => {
    setAnswers({
      ...answers,
      [currentQuestion]: answerId,
    })
  }

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const handleSubmitTest = () => {
    alert(`Test submitted! You answered ${Object.keys(answers).length} out of ${questions.length} questions.`)
  }

  if (!isTestStarted) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Header />

        <main className="flex-1 container mx-auto px-4 py-12 flex items-center justify-center">
          <Card className="max-w-2xl w-full">
            <CardHeader>
              <CardTitle className="text-3xl">SSC JE Preliminary - General Awareness</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Total Questions</h4>
                    <p className="text-muted-foreground">{questions.length} Questions</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="text-blue-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Duration</h4>
                    <p className="text-muted-foreground">120 Minutes</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="text-orange-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Difficulty</h4>
                    <p className="text-muted-foreground">Medium</p>
                  </div>
                </div>
              </div>
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <p className="text-sm text-yellow-900">
                  <strong>Note:</strong> This is a practice test. Negative marking will not be applied.
                </p>
              </div>
              <Button size="lg" onClick={() => setIsTestStarted(true)} className="w-full">
                Start Test
              </Button>
            </CardContent>
          </Card>
        </main>

        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Test Area */}
          <div className="lg:col-span-3">
            <MockTestQuestion
              questionNumber={currentQuestion + 1}
              totalQuestions={questions.length}
              question={questions[currentQuestion].question}
              options={questions[currentQuestion].options}
              selectedAnswer={answers[currentQuestion]}
              onAnswerSelect={handleAnswerSelect}
            />

            {/* Navigation Buttons */}
            <div className="flex gap-4 mt-8">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={currentQuestion === 0}
                className="flex items-center gap-2 bg-transparent"
              >
                <ArrowLeft size={18} />
                Previous
              </Button>
              <Button
                onClick={handleNext}
                disabled={currentQuestion === questions.length - 1}
                className="flex items-center gap-2"
              >
                Next
                <ArrowRight size={18} />
              </Button>
              {currentQuestion === questions.length - 1 && (
                <Button onClick={handleSubmitTest} variant="default" className="ml-auto">
                  Submit Test
                </Button>
              )}
            </div>
          </div>

          {/* Question Palette */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Questions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-4 lg:grid-cols-5 gap-2">
                  {questions.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentQuestion(index)}
                      className={`p-2 rounded-lg font-semibold text-sm transition-colors ${
                        currentQuestion === index
                          ? "bg-primary text-white"
                          : answers[index]
                            ? "bg-green-100 text-green-800"
                            : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                    >
                      {index + 1}
                    </button>
                  ))}
                </div>
                <div className="mt-6 space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-green-100 rounded"></div>
                    <span>Answered</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-gray-100 rounded"></div>
                    <span>Not Answered</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
