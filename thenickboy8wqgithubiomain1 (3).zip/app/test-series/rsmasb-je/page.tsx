"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import MockTestQuestion from "@/components/mock-test-question"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { ArrowRight, ArrowLeft } from "lucide-react"

export default function RSMASBJETestPage() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [isTestStarted, setIsTestStarted] = useState(false)

  const questions = [
    {
      id: 1,
      question: "What is the maximum tensile strength of mild steel?",
      options: [
        { id: "a", text: "200 MPa" },
        { id: "b", text: "250 MPa" },
        { id: "c", text: "300 MPa" },
        { id: "d", text: "350 MPa" },
      ],
    },
    {
      id: 2,
      question: "In hydraulics, what does 'Pascal's Law' state?",
      options: [
        { id: "a", text: "Pressure is directly proportional to depth" },
        { id: "b", text: "Pressure applied is transmitted equally in all directions" },
        { id: "c", text: "Pressure is inversely proportional to area" },
        { id: "d", text: "Pressure has no effect on incompressible fluids" },
      ],
    },
    {
      id: 3,
      question: "What is the SI unit of torque?",
      options: [
        { id: "a", text: "Newton" },
        { id: "b", text: "Joule" },
        { id: "c", text: "Newton-meter" },
        { id: "d", text: "Watt" },
      ],
    },
  ]

  const handleAnswerSelect = (answerId: string) => {
    setAnswers({
      ...answers,
      [currentQuestion]: answerId,
    })
  }

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const handleSubmitTest = () => {
    alert(`Test submitted! You answered ${Object.keys(answers).length} out of ${questions.length} questions.`)
  }

  if (!isTestStarted) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Header />
        <main className="flex-1 container mx-auto px-4 py-12 flex items-center justify-center">
          <Card className="max-w-2xl w-full">
            <CardHeader>
              <CardTitle className="text-3xl">RSMASB JE - Full Length Mock Test</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="text-lg font-semibold">Test Details:</div>
                <div>Total Questions: {questions.length}</div>
                <div>Duration: 150 Minutes</div>
                <div>Difficulty: Hard</div>
              </div>
              <Button size="lg" onClick={() => setIsTestStarted(true)} className="w-full">
                Start Test
              </Button>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3">
            <MockTestQuestion
              questionNumber={currentQuestion + 1}
              totalQuestions={questions.length}
              question={questions[currentQuestion].question}
              options={questions[currentQuestion].options}
              selectedAnswer={answers[currentQuestion]}
              onAnswerSelect={handleAnswerSelect}
            />
            <div className="flex gap-4 mt-8">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={currentQuestion === 0}
                className="flex items-center gap-2 bg-transparent"
              >
                <ArrowLeft size={18} />
                Previous
              </Button>
              <Button
                onClick={handleNext}
                disabled={currentQuestion === questions.length - 1}
                className="flex items-center gap-2"
              >
                Next
                <ArrowRight size={18} />
              </Button>
              {currentQuestion === questions.length - 1 && (
                <Button onClick={handleSubmitTest} variant="default" className="ml-auto">
                  Submit Test
                </Button>
              )}
            </div>
          </div>
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Questions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-4 lg:grid-cols-5 gap-2">
                  {questions.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentQuestion(index)}
                      className={`p-2 rounded-lg font-semibold text-sm transition-colors ${
                        currentQuestion === index
                          ? "bg-primary text-white"
                          : answers[index]
                            ? "bg-green-100 text-green-800"
                            : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                    >
                      {index + 1}
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
