"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import MockTestQuestion from "@/components/mock-test-question"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { ArrowRight, ArrowLeft } from "lucide-react"

export default function SSCCGLTestPage() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [isTestStarted, setIsTestStarted] = useState(false)

  const questions = [
    {
      id: 1,
      question: "Who was the first President of India?",
      options: [
        { id: "a", text: "Jawaharlal Nehru" },
        { id: "b", text: "Dr. Rajendra Prasad" },
        { id: "c", text: "K. R. Narayanan" },
        { id: "d", text: "Pranab Mukherjee" },
      ],
    },
    {
      id: 2,
      question: "What is the capital of France?",
      options: [
        { id: "a", text: "Lyon" },
        { id: "b", text: "Paris" },
        { id: "c", text: "Marseille" },
        { id: "d", text: "Nice" },
      ],
    },
    {
      id: 3,
      question: "Which planet is closest to the Sun?",
      options: [
        { id: "a", text: "Venus" },
        { id: "b", text: "Mercury" },
        { id: "c", text: "Earth" },
        { id: "d", text: "Mars" },
      ],
    },
  ]

  const handleAnswerSelect = (answerId: string) => {
    setAnswers({
      ...answers,
      [currentQuestion]: answerId,
    })
  }

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const handleSubmitTest = () => {
    alert(`Test submitted! You answered ${Object.keys(answers).length} out of ${questions.length} questions.`)
  }

  if (!isTestStarted) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Header />
        <main className="flex-1 container mx-auto px-4 py-12 flex items-center justify-center">
          <Card className="max-w-2xl w-full">
            <CardHeader>
              <CardTitle className="text-3xl">SSC CGL Tier 1 - General Awareness</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="text-lg font-semibold">Test Details:</div>
                <div>Total Questions: {questions.length}</div>
                <div>Duration: 60 Minutes</div>
                <div>Difficulty: Easy</div>
              </div>
              <Button size="lg" onClick={() => setIsTestStarted(true)} className="w-full">
                Start Test
              </Button>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3">
            <MockTestQuestion
              questionNumber={currentQuestion + 1}
              totalQuestions={questions.length}
              question={questions[currentQuestion].question}
              options={questions[currentQuestion].options}
              selectedAnswer={answers[currentQuestion]}
              onAnswerSelect={handleAnswerSelect}
            />
            <div className="flex gap-4 mt-8">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={currentQuestion === 0}
                className="flex items-center gap-2 bg-transparent"
              >
                <ArrowLeft size={18} />
                Previous
              </Button>
              <Button
                onClick={handleNext}
                disabled={currentQuestion === questions.length - 1}
                className="flex items-center gap-2"
              >
                Next
                <ArrowRight size={18} />
              </Button>
              {currentQuestion === questions.length - 1 && (
                <Button onClick={handleSubmitTest} variant="default" className="ml-auto">
                  Submit Test
                </Button>
              )}
            </div>
          </div>
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Questions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-4 lg:grid-cols-5 gap-2">
                  {questions.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentQuestion(index)}
                      className={`p-2 rounded-lg font-semibold text-sm transition-colors ${
                        currentQuestion === index
                          ? "bg-primary text-white"
                          : answers[index]
                            ? "bg-green-100 text-green-800"
                            : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                    >
                      {index + 1}
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
