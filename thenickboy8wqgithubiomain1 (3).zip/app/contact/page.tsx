"use client"

import type React from "react"

import Header from "@/components/header"
import Footer from "@/components/footer"
import { Mail, Phone, MapPin } from "lucide-react"
import { useState } from "react"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Form submitted:", formData)
    alert("Thank you! We will get back to you soon.")
    setFormData({ name: "", email: "", subject: "", message: "" })
  }

  return (
    <>
      <Header />
      <main className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-4xl font-bold mb-3 text-foreground">Contact Us</h1>
          <p className="text-lg text-muted-foreground mb-12">
            Have questions? We'd love to hear from you. Get in touch with us anytime.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="bg-white rounded-lg p-8 border border-border text-center">
              <Mail className="w-12 h-12 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-bold text-foreground mb-2">Email</h3>
              <p className="text-muted-foreground">harendra@selectionway.com</p>
            </div>
            <div className="bg-white rounded-lg p-8 border border-border text-center">
              <Phone className="w-12 h-12 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-bold text-foreground mb-2">Phone</h3>
              <p className="text-muted-foreground">+91-9876543210</p>
            </div>
            <div className="bg-white rounded-lg p-8 border border-border text-center">
              <MapPin className="w-12 h-12 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-bold text-foreground mb-2">Location</h3>
              <p className="text-muted-foreground">Delhi, India</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg p-8 border border-border">
              <h2 className="text-2xl font-bold text-foreground mb-6">Send us a Message</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-foreground font-semibold mb-2">Name</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:border-primary"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label className="block text-foreground font-semibold mb-2">Email</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:border-primary"
                    placeholder="Your email"
                  />
                </div>
                <div>
                  <label className="block text-foreground font-semibold mb-2">Subject</label>
                  <input
                    type="text"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:border-primary"
                    placeholder="Subject"
                  />
                </div>
                <div>
                  <label className="block text-foreground font-semibold mb-2">Message</label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={5}
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:border-primary resize-none"
                    placeholder="Your message"
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="w-full bg-primary text-white py-3 rounded-lg font-bold hover:bg-primary-dark transition"
                >
                  Send Message
                </button>
              </div>
            </form>

            <div className="bg-primary text-white rounded-lg p-8">
              <h2 className="text-2xl font-bold mb-6">Why Get In Touch?</h2>
              <ul className="space-y-4">
                <li className="flex gap-3">
                  <span>✓</span>
                  <span>Get expert guidance for your SSC preparation</span>
                </li>
                <li className="flex gap-3">
                  <span>✓</span>
                  <span>Inquire about our courses and programs</span>
                </li>
                <li className="flex gap-3">
                  <span>✓</span>
                  <span>Book a free consultation session</span>
                </li>
                <li className="flex gap-3">
                  <span>✓</span>
                  <span>Get answers to your questions</span>
                </li>
              </ul>
              <div className="mt-8 pt-8 border-t border-white/20">
                <p className="text-white/90">We're here to help you succeed. Reach out to us anytime!</p>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
