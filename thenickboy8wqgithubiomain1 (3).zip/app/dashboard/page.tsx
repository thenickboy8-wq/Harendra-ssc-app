"use client"

import { BookOpen, Clock, CheckCircle, Zap } from "lucide-react"
import Header from "@/components/header"
import Footer from "@/components/footer"
import Link from "next/link"

export default function Dashboard() {
  return (
    <main className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <div className="mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-2">Welcome back, Student!</h1>
            <p className="text-muted-foreground text-lg">Track your progress and continue learning</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
            <div className="bg-white rounded-xl p-6 shadow-lg border-l-4 border-blue-500">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-muted-foreground text-sm mb-1">Tests Attempted</p>
                  <p className="text-3xl font-bold text-foreground">24</p>
                </div>
                <CheckCircle className="text-blue-500" size={32} />
              </div>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-lg border-l-4 border-green-500">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-muted-foreground text-sm mb-1">Current Rank</p>
                  <p className="text-3xl font-bold text-foreground">#342</p>
                </div>
                <Zap className="text-green-500" size={32} />
              </div>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-lg border-l-4 border-purple-500">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-muted-foreground text-sm mb-1">Avg Score</p>
                  <p className="text-3xl font-bold text-foreground">76%</p>
                </div>
                <BookOpen className="text-purple-500" size={32} />
              </div>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-lg border-l-4 border-orange-500">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-muted-foreground text-sm mb-1">Study Hours</p>
                  <p className="text-3xl font-bold text-foreground">142</p>
                </div>
                <Clock className="text-orange-500" size={32} />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-2xl font-bold mb-6 text-foreground">Continue Learning</h3>
              <div className="space-y-4">
                <Link
                  href="/test-series/ssc-je"
                  className="block p-4 border border-border rounded-lg hover:bg-muted transition"
                >
                  <p className="font-semibold text-foreground">SSC JE Mock Test - Set 5</p>
                  <p className="text-sm text-muted-foreground">Progress: 45%</p>
                </Link>
                <Link
                  href="/live-classes"
                  className="block p-4 border border-border rounded-lg hover:bg-muted transition"
                >
                  <p className="font-semibold text-foreground">Live Class: Quantitative Aptitude</p>
                  <p className="text-sm text-muted-foreground">Starts in 2 hours</p>
                </Link>
                <Link
                  href="/doubt-section"
                  className="block p-4 border border-border rounded-lg hover:bg-muted transition"
                >
                  <p className="font-semibold text-foreground">Ask Doubt: Algebra Topics</p>
                  <p className="text-sm text-muted-foreground">3 unanswered doubts</p>
                </Link>
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-xl shadow-lg p-8">
              <h3 className="text-2xl font-bold mb-6">Recommended For You</h3>
              <div className="space-y-4">
                <div className="bg-white/10 rounded-lg p-4 backdrop-blur">
                  <p className="font-semibold mb-1">Weakness: Time Management</p>
                  <p className="text-sm text-white/80">Practice more speed tests</p>
                </div>
                <div className="bg-white/10 rounded-lg p-4 backdrop-blur">
                  <p className="font-semibold mb-1">Strong Topic: English Grammar</p>
                  <p className="text-sm text-white/80">Score: 88% - Keep it up!</p>
                </div>
                <button className="w-full bg-white text-blue-600 py-3 rounded-lg font-bold hover:bg-gray-100 transition mt-4">
                  View Full Analysis
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8">
            <h3 className="text-2xl font-bold mb-6 text-foreground">Recent Activity</h3>
            <div className="space-y-4">
              {[
                { date: "Today", activity: "Completed SSC CGL Mock Test - Scored 82%", status: "completed" },
                { date: "Yesterday", activity: "Attended Live Class: General Awareness", status: "attended" },
                { date: "2 days ago", activity: "Posted doubt: Trigonometry - Cleared", status: "resolved" },
                { date: "3 days ago", activity: "Completed 15 hours study in a week", status: "milestone" },
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-4 pb-4 border-b border-border last:border-b-0">
                  <div
                    className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                      item.status === "completed"
                        ? "bg-green-100 text-green-600"
                        : item.status === "attended"
                          ? "bg-blue-100 text-blue-600"
                          : item.status === "resolved"
                            ? "bg-purple-100 text-purple-600"
                            : "bg-orange-100 text-orange-600"
                    }`}
                  >
                    <CheckCircle size={24} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-muted-foreground">{item.date}</p>
                    <p className="font-semibold text-foreground">{item.activity}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
