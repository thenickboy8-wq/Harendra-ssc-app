"use client"

import { useState } from "react"
import Header from "@/components/header"
import Footer from "@/components/footer"
import DoubtCard from "@/components/doubt-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Search } from "lucide-react"

export default function DoubtSectionPage() {
  const [doubts, setDoubts] = useState([
    {
      id: "1",
      title: "How to solve quadratic equations?",
      description: "I'm having trouble understanding the discriminant method",
      askedBy: "Rajesh Kumar",
      replies: 5,
      likes: 12,
      status: "resolved" as const,
      subject: "Mathematics",
    },
    {
      id: "2",
      title: "Difference between AC and DC current",
      description: "Can someone explain the basic difference clearly?",
      askedBy: "Priya Singh",
      replies: 3,
      likes: 8,
      status: "resolved" as const,
      subject: "Physics",
    },
    {
      id: "3",
      title: "Indian history - Mughal Empire",
      description: "Which emperor ruled the longest in Mughal Empire?",
      askedBy: "Arjun Patel",
      replies: 2,
      likes: 6,
      status: "open" as const,
      subject: "History",
    },
    {
      id: "4",
      title: "English grammar - Active and Passive voice",
      description: "Need clarification on voice transformation rules",
      askedBy: "Neha Sharma",
      replies: 4,
      likes: 9,
      status: "open" as const,
      subject: "English",
    },
  ])

  const [searchQuery, setSearchQuery] = useState("")

  const filteredDoubts = doubts.filter(
    (doubt) =>
      doubt.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doubt.subject.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handlePostDoubt = (title: string, description: string, subject: string) => {
    const newDoubt = {
      id: String(doubts.length + 1),
      title,
      description,
      subject,
      askedBy: "You",
      replies: 0,
      likes: 0,
      status: "open" as const,
    }
    setDoubts([newDoubt, ...doubts])
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-12">
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between mb-6">
            <div>
              <h1 className="text-4xl font-bold text-foreground mb-2">Doubt Section</h1>
              <p className="text-muted-foreground">Ask your questions and get answers from instructors and peers</p>
            </div>
            <PostDoubtDialog onPostDoubt={handlePostDoubt} />
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-3 text-muted-foreground" size={20} />
            <Input
              placeholder="Search doubts by title or subject..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="all">All Doubts</TabsTrigger>
            <TabsTrigger value="open">Open</TabsTrigger>
            <TabsTrigger value="resolved">Resolved</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            {filteredDoubts.map((doubt) => (
              <DoubtCard key={doubt.id} {...doubt} />
            ))}
          </TabsContent>

          <TabsContent value="open" className="space-y-4">
            {filteredDoubts
              .filter((d) => d.status === "open")
              .map((doubt) => (
                <DoubtCard key={doubt.id} {...doubt} />
              ))}
          </TabsContent>

          <TabsContent value="resolved" className="space-y-4">
            {filteredDoubts
              .filter((d) => d.status === "resolved")
              .map((doubt) => (
                <DoubtCard key={doubt.id} {...doubt} />
              ))}
          </TabsContent>
        </Tabs>
      </main>

      <Footer />
    </div>
  )
}

function PostDoubtDialog({
  onPostDoubt,
}: { onPostDoubt: (title: string, description: string, subject: string) => void }) {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [subject, setSubject] = useState("Mathematics")
  const [open, setOpen] = useState(false)

  const handleSubmit = () => {
    if (title.trim() && description.trim()) {
      onPostDoubt(title, description, subject)
      setTitle("")
      setDescription("")
      setSubject("Mathematics")
      setOpen(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-2">
          <Plus size={18} />
          Post Doubt
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Post Your Doubt</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-semibold mb-2 block">Subject</label>
            <select
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full px-3 py-2 border border-border rounded-lg"
            >
              <option>Mathematics</option>
              <option>Physics</option>
              <option>Chemistry</option>
              <option>English</option>
              <option>History</option>
              <option>Geography</option>
              <option>General Awareness</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-semibold mb-2 block">Question Title</label>
            <Input
              placeholder="Write a clear title for your question"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>
          <div>
            <label className="text-sm font-semibold mb-2 block">Description</label>
            <Textarea
              placeholder="Provide more details about your doubt..."
              rows={6}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          <div className="flex gap-3 justify-end">
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit}>Post Doubt</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
