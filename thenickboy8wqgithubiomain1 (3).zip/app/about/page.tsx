import Header from "@/components/header"
import Footer from "@/components/footer"

export const metadata = {
  title: "About - Selection Way Harendra SSC",
  description: "About Selection Way Harendra coaching",
}

export default function AboutPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-4xl font-bold mb-8 text-foreground">About Selection Way Harendra SSC</h1>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-12">
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-4">Our Mission</h2>
              <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                Selection Way Harendra SSC is dedicated to helping students prepare for SSC exams with clear notes,
                expert guidance, and regular practice. We believe that with the right strategy and support, every
                student can crack the SSC exam.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Our goal is to make quality education accessible to all students, regardless of their background or
                financial situation.
              </p>
            </div>
            <div className="bg-primary text-white rounded-lg p-8">
              <h2 className="text-2xl font-bold mb-6">Why Choose Us?</h2>
              <ul className="space-y-4">
                <li className="flex gap-3">
                  <div className="w-6 h-6 bg-white/30 rounded-full flex items-center justify-center flex-shrink-0">
                    ✓
                  </div>
                  <span>Expert instructors with years of experience</span>
                </li>
                <li className="flex gap-3">
                  <div className="w-6 h-6 bg-white/30 rounded-full flex items-center justify-center flex-shrink-0">
                    ✓
                  </div>
                  <span>Comprehensive syllabus coverage</span>
                </li>
                <li className="flex gap-3">
                  <div className="w-6 h-6 bg-white/30 rounded-full flex items-center justify-center flex-shrink-0">
                    ✓
                  </div>
                  <span>Live classes with doubt clearing</span>
                </li>
                <li className="flex gap-3">
                  <div className="w-6 h-6 bg-white/30 rounded-full flex items-center justify-center flex-shrink-0">
                    ✓
                  </div>
                  <span>Regular mock tests and evaluations</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="bg-muted rounded-lg p-8">
            <h2 className="text-2xl font-bold text-foreground mb-6">Our Team</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {["Harendra Sir", "Priya Ma'am", "Sharma Sir"].map((instructor) => (
                <div key={instructor} className="bg-white rounded-lg p-6 text-center border border-border">
                  <div className="w-24 h-24 bg-primary rounded-full mx-auto mb-4"></div>
                  <h3 className="font-bold text-lg text-foreground">{instructor}</h3>
                  <p className="text-muted-foreground">Expert Instructor</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
