import Header from "@/components/header"
import Footer from "@/components/footer"

export const metadata = {
  title: "SSC Syllabus - Selection Way Harendra",
  description: "Complete SSC exam syllabus and exam pattern",
}

export default function SyllabusPage() {
  const subjects = [
    {
      name: "General Awareness",
      topics: ["Current Affairs", "History", "Geography", "Science", "Economics"],
    },
    {
      name: "Quantitative Aptitude",
      topics: ["Arithmetic", "Algebra", "Geometry", "Trigonometry", "Data Interpretation"],
    },
    {
      name: "English Language",
      topics: ["Grammar", "Reading Comprehension", "Vocabulary", "Writing Skills", "Spotting Errors"],
    },
    {
      name: "Reasoning Ability",
      topics: ["Analogy", "Classification", "Series", "Coding-Decoding", "Logical Reasoning"],
    },
  ]

  return (
    <>
      <Header />
      <main className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-4xl font-bold mb-3 text-foreground">SSC Exam Syllabus</h1>
          <p className="text-lg text-muted-foreground mb-12">
            Comprehensive syllabus for SSC CGL, CHSL, and other SSC exams
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {subjects.map((subject) => (
              <div key={subject.name} className="bg-white rounded-lg p-8 border border-border">
                <h2 className="text-2xl font-bold text-foreground mb-6">{subject.name}</h2>
                <ul className="space-y-3">
                  {subject.topics.map((topic) => (
                    <li key={topic} className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                      <span className="text-foreground">{topic}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-12 bg-primary text-white rounded-lg p-8">
            <h2 className="text-2xl font-bold mb-4">Exam Pattern</h2>
            <p className="mb-6">
              The SSC CGL exam consists of 4 tiers testing your General Awareness, Quantitative Aptitude, English
              Language, and Reasoning Ability.
            </p>
            <button className="bg-white text-primary px-8 py-3 rounded-lg font-bold hover:bg-gray-100 transition">
              Download Detailed Syllabus PDF
            </button>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
