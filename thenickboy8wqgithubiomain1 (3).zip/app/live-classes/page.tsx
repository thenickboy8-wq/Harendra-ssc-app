import Header from "@/components/header"
import Footer from "@/components/footer"
import LiveClassCard from "@/components/live-class-card"

export const metadata = {
  title: "Live Classes - Selection Way Harendra SSC",
  description: "Join our live classes for SSC exam preparation",
}

export default function LiveClassesPage() {
  const allClasses = [
    {
      id: 1,
      subject: "General Awareness",
      instructor: "Harendra Sir",
      time: "10:00 AM",
      date: "Today",
      students: 245,
      status: "LIVE" as const,
    },
    {
      id: 2,
      subject: "Quantitative Aptitude",
      instructor: "Priya Ma'am",
      time: "2:00 PM",
      date: "Today",
      students: 189,
      status: "UPCOMING" as const,
    },
    {
      id: 3,
      subject: "English Language",
      instructor: "Sharma Sir",
      time: "4:30 PM",
      date: "Tomorrow",
      students: 167,
      status: "UPCOMING" as const,
    },
    {
      id: 4,
      subject: "Reasoning Ability",
      instructor: "Kumar Sir",
      time: "6:00 PM",
      date: "Tomorrow",
      students: 203,
      status: "UPCOMING" as const,
    },
    {
      id: 5,
      subject: "General Science",
      instructor: "Verma Sir",
      time: "10:00 AM",
      date: "Day after",
      students: 178,
      status: "UPCOMING" as const,
    },
    {
      id: 6,
      subject: "History & Culture",
      instructor: "Sharma Ma'am",
      time: "3:00 PM",
      date: "Day after",
      students: 156,
      status: "UPCOMING" as const,
    },
  ]

  return (
    <>
      <Header />
      <main className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-4xl font-bold mb-3 text-foreground">All Live Classes</h1>
          <p className="text-lg text-muted-foreground mb-12">
            Join our expert-led live classes and prepare for SSC with guided instruction
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {allClasses.map((liveClass) => (
              <LiveClassCard key={liveClass.id} {...liveClass} />
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
