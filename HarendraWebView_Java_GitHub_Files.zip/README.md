
        Harendra WebView Android App (Java)
        ----------------------------------
        This is a minimal Android Studio project (Java) that loads a local index.html from assets in a WebView.
        
        How to open:
        - Download and unzip the project.
        - Open Android Studio -> Open an existing project -> select the folder.
        - Let Gradle sync (you may need an internet connection the first time to download dependencies).
        - Run on a device or emulator.
        
        If you want, I can:
        - Add your website HTML files into app/src/main/assets/
        - Create an APK for you (you will have to upload full project or give me the repo link).
    