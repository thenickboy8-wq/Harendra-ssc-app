
        package com.selectionway.harendra;
        import android.os.Bundle;
        import android.webkit.WebView;
        import android.webkit.WebViewClient;
        import androidx.appcompat.app.AppCompatActivity;
        public class MainActivity extends AppCompatActivity {
            private WebView webView;
            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                webView = new WebView(this);
                webView.getSettings().setJavaScriptEnabled(true);
                webView.setWebViewClient(new WebViewClient());
                // load the local index.html from assets
                webView.loadUrl("file:///android_asset/index.html");
                setContentView(webView);
            }
            @Override
            public void onBackPressed() {
                if (webView.canGoBack()) webView.goBack();
                else super.onBackPressed();
            }
        }
    